
package chl.hajo.library.core;

/**
 * The genre of the book
 * @author hajo
 */
public enum Genre {
    THRILLER, NOVEL, ROMANTIC_NOVEL, BIOGRAPHY; 
    
}
