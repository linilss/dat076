package chl.hajo.library.core;

/**
 * A connection of a book to an author
 * @author hajo
 */

public class Publication {

  
    
    
}
